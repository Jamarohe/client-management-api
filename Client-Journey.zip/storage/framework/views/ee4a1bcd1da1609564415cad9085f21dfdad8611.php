<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Vista ejemplo</title>
</head>
<body>
    <h1>Travels</h1>

    <table>
        <thead>
            <tr>
                <th> id</th>
                <th> email</th>
                <th> name</th>
                <th> lastname</th>
                <th> cellphone</th> 
                <th> date  </th>
                <th> country </th>
                <th> city</th> 
            </tr>
        </thead> 
        <tbody>
            <?php $__currentLoopData = $travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($travel->id); ?> </td>
                <td> <?php echo e($travel->email_fk); ?> </td>
                <td> <?php echo e($travel->name); ?> </td>
                <td> <?php echo e($travel->lastname); ?> </td>
                <td> <?php echo e($travel->cellphone); ?> </td>
                <td> <?php echo e($travel->date); ?> </td>
                <td> <?php echo e($travel->country); ?> </td>
                <td> <?php echo e($travel->city); ?> </td> 
                <td> <a data-method="delete" href="<?php echo e(action('TravelController@delete' ,['id' => $travel->id])); ?>" class="jquery-postback"><button class="btn btn-danger">
                        X
                    </button>
                    </a>
                </td> 
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>

<script>
$.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
});
$(document).on('click', 'a.jquery-postback', function(e) {
    e.preventDefault(); // does not go through with the link.

    var $this = $(this);

    $.post({
        type: $this.data('method'),
        url: $this.attr('href')
    }).done(function (data) {
        alert('success');
        console.log(data);
    });
});
</script><?php /**PATH C:\Users\jahel\Documents\proyectos\EntrevistaNuvola\Client-Journey\resources\views/journey.blade.php ENDPATH**/ ?>